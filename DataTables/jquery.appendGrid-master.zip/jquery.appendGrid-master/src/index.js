// import AppendGrid class
import AppendGrid from './lib/ag-main';

// export default AppendGrid class
export default AppendGrid;